<?php
  session_start();
  
  // Check if the user has logged in
  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] === false){
    header("location: index.php");
    exit;
  }

  // Include database config file
  require_once "config.php";
  $username = $_SESSION["username"];

  // fetch data corresponding to the username from database
  $sql = "SELECT * FROM userinfo WHERE username = '$username'";
  $result = $conn->query($sql);
  
  $row = $result->fetch_assoc();
  $fullname = $row["fullname"];
  $userID = $row["userID"];
  $company = $row["companyName"];
  $companyID = $row["companyID"];
  $email = $row["email"];
  
  // save user info as cookies
  $_SESSION["userID"] = $userID;
  $_SESSION["company"] = $company;
  $_SESSION["companyID"] = $companyID;
  $_SESSION["email"] = $email;
  $_SESSION["userFullname"] = $fullname;

  $conn->close();  
?>

<!doctype html>
<html lang="en-US">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> DNES - Home </title>

<link href="css/selectedOptionTemplate.css" rel="stylesheet" type="text/css">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600;1,700;1,900&display=swap" rel="stylesheet"> 
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> 
    <nav2>
      <a href="Home.php"> 
        <img src="images/circle_logo.svg" alt= "DNES logo" height="100%"/>
      </a> 
	  </nav2>  
    <nav>
      <ul>
        <li><a href="index.php">LOGOUT</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
	<div class="multiple_items_V">
	 	  <img src="images/namelogo.svg" alt= "DNES logo" width="30%"/> 
	  </div>
  
		<h2 class="hero_header">DNES: <span class="light">SMARTER MATERIAL BROKERING TODAY</span></h2>
  </section>
	
  <section>
  <!-- Stats Gallery Section -->
	  <div class="gallery">
      <div class="thumbnail" onclick="document.location='addMaterial.php'">
        <div class="button2">1. Add New Material </div>
      </div>
        <div class="thumbnail" onclick="document.location='addOrder.php'">
        <div class="button2">2. Add New Order </div>
      </div>
        <div class="thumbnail" onclick="document.location='viewCurrentOrders.php'">
        <div class="button2">3. View Current Orders </div>
      </div>
      <div class="thumbnail" onclick="document.location='viewPastOrders.php'">
        <div class="button2">4. View Past Orders </div>
      </div>
	  </div>
</section>
  <!-- Parallax Section -->
  <section style="height: auto; background-color: #2D9AB7; padding: 50px">
    <h2 class="parallax">Select one of the Options Above</h2>
  </section>

  <section class= "multiple_items_H" 	style="background-color:#FFFFFF">
	
	<div class="multiple_items_V" style="width=100%">
		 <img src="images/Sixth Step.svg" alt= "throughout" height="600"/>
		 <h2 style="text-align:center">Partnerships Simplified</h2>
		 <h3 2 style="text-align:center;max-width: 70%">Data is automatically shared digitally to all companies of the order creating a transparent and trustworthy collaboration space</h3>
	</div>
</section>

  <!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">To interact with the hardware </p>
    <div class="button" onclick="document.location='https\://dnes-mobile.herokuapp.com/'">Go to the App</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2021- <strong>theDNES.com</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>
