<?php
    require_once "config.php";

    $company = htmlspecialchars($_POST['company']);
    $text = isset($_GET['text'])? $_GET['text'] : "";

    if($company!='') {
        $sql = "SELECT * FROM userinfo WHERE companyName='$company'";
        $result = $conn->query($sql);
        echo "<option value=''> -- ". $text. " --</option>";

        // show query result in a dropdown menu
        while ($row = $result->fetch_assoc()) {
            echo "<option value='". $row['userID'] ."'>" .$row['fullname'] ."</option>";
        }
    }

    $conn->close(); 
?>