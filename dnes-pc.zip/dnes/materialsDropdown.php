<?php
    require_once "config.php";

    $company = htmlspecialchars($_POST['company']);

    if($company!='') {
        $sql = "SELECT * FROM materialinfo WHERE sourceName='$company' AND isActivated = 1";
        $result = $conn->query($sql);
        echo "<option value=''>-- Select Material --</option>";

        // show query result in a dropdown menu
        while ($row = $result->fetch_assoc()) {
            echo "<option value='". $row['materialID'] ."'>" .$row['materialName'] ."</option>";
        }
    }

    $conn->close();
?>

