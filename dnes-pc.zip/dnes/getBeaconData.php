<?php
    // save information comes from beacon as variables 
    $data = isset($_GET['data'])? $_GET['data']: "";
    $arr = json_decode($data, true);

    $beaconID = isset($arr['beaconID']) ? $arr['beaconID']: "";
    $moistureLevel = isset($arr['moistureLevel']) ? $arr['moistureLevel']: "NULL";
    $geoLat = isset($arr['geoLat']) ? $arr['geoLat']: "";
    $geoLong = isset($arr['geoLong']) ? $arr['geoLong']: "";
    $distanceTraveled = isset($arr['distanceTraveled']) ? $arr['distanceTraveled']: "NULL";
    $pingTime = date('Y-m-d H:i:s');

    // echo "beaconID: ". $beaconID;
    // echo "moistureLevel: ". $moistureLevel;
    // echo "geoLat: ". $geoLat;
    // echo "geoLong: ". $geoLong;
    // echo "distanceTraveled: ". $distanceTraveled;

    require_once "config.php";

    // get the latest status of the beacon from the database
    $sql = "SELECT * FROM beaconinfo WHERE beaconID = '$beaconID' ORDER BY pingTime DESC LIMIT 1";
    $result = $conn->query($sql);
    
    // save beacon data into the database
    if ($row = $result->fetch_assoc()){
        // if the beacon is already registered, check which status the beacon is in
        $beaconStatus = $row['beaconStatus'];

        // Case 1: the beacon is in Standby or Completed
        if ($beaconStatus == 'Completed' OR $beaconStatus == 'Standby') {
            $sql = "UPDATE beaconinfo
                    SET moistureLevel = $moistureLevel, pingTime = '$pingTime',
                        geoLat = $geoLat, geoLong = $geoLong
                    WHERE beaconID = '$beaconID' AND beaconStatus = 'Standby'";
            $conn->query($sql);
        
        // Case 2: the beacon is Onsite
        } else if ($beaconStatus == 'Onsite') {
            $materialID = $row['materialID'];
            $sql = "INSERT INTO beaconinfo (beaconID, materialID, beaconStatus, pingTime, moistureLevel, geoLat, geoLong)
                    VALUES ('$beaconID', '$materialID', '$beaconStatus', '$pingTime', $moistureLevel, $geoLat, $geoLong)";
            $conn->query($sql);
        
        // Case 3: the beacon is In-transit
        } else {
            $orderID = $row['orderID'];
            $sql = "INSERT INTO beaconinfo (beaconID, orderID, beaconStatus, pingTime, moistureLevel, geoLat, geoLong, distanceTraveled)
                    VALUES ('$beaconID', '$orderID', '$beaconStatus', '$pingTime', $moistureLevel, $geoLat, $geoLong, $distanceTraveled)";
            $conn->query($sql);
        }
    
    // Edge case: the beacon has not been registered
    } else {
        $beaconStatus = "Standby";
        $sql = "INSERT INTO beaconinfo (beaconID, beaconStatus, pingTime, moistureLevel, geoLat, geoLong)
                VALUES ('$beaconID', '$beaconStatus', '$pingTime', $moistureLevel, $geoLat, $geoLong)";
        $conn->query($sql);
        
    }
    
    echo("Error description: " . mysqli_error($conn));
    $conn->close();
?>